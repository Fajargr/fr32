
![Screenshot_20200830-125319](https://user-images.githubusercontent.com/57522482/92686224-c0f8e580-f328-11ea-94a1-5cdf13503836.png)
<br>
![Screenshot_20200902-190322](https://user-images.githubusercontent.com/57522482/92684934-2dbeb080-f326-11ea-8975-0695bd306723.png)



<br>

<h3 style="color:red"> Tool Make By:Abm Mujahid</h3>
<br>
Tool Install:<br>
pkg update -y<br>
pkg install git php bash curl openssh wget -y<br>

git clone https://github.com/bd8kr3m/bos-p.git<br>

cd bos-p

chmod +x *

bash bos-p.sh

### Or ; Use Single Command
```
apt upgrade && apt install git -y && git clone https://github.com/bd8kr3m/bos-p && cd bos-p && bash bos-p.sh
```

<h2>Ok Enjoy The Tool </h2>
<h3>Follow Me:</h3>
Facebook:https://m.Facebook.com/Bd8kr3m<br>
YouTube: suspend 💔
<br>
<h1> Don't Copy My Script </h1> 

<br>
